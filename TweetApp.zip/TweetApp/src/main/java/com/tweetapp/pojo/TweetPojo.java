package com.tweetapp.pojo;

public class TweetPojo {

	private String emailId;
	private String tweetText;
	private String time;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getTweetText() {
		return tweetText;
	}

	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public TweetPojo(String emailId, String tweetText, String time) {
		super();
		this.emailId = emailId;
		this.tweetText = tweetText;
		this.time = time;
	}

	public TweetPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "TweetPojo [emailId=" + emailId + ", tweetText=" + tweetText + ", time=" + time + "]";
	}

}
