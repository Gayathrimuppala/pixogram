package com.tweetapp;

import java.io.IOException;
import java.sql.SQLException;

import com.tweetapp.service.MenuService;

public class TweetApp {

	public static void main(String[] args) throws IOException, SQLException {
		// TODO Auto-generated method stub
		MenuService.Welcome();
		MenuService menu = new MenuService();
		menu.homeMenu();
		System.out.println("Thanks for using TweetApp");

	}

}
