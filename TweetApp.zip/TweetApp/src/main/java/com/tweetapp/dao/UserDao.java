package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tweetapp.pojo.TweetPojo;

public class UserDao {

	static Connection connnection = DBConnection.getConnection();

	public String getUserName(String email) throws SQLException {
		// TODO Auto-generated method stub

		String userNameQuery = "SELECT first_name FROM tweet_app.user_table Where email_id=?; ";
		PreparedStatement statement = connnection.prepareStatement(userNameQuery);
		statement.setString(1, email);
		ResultSet resultSet = statement.executeQuery();
		String userName = null;
		while (resultSet.next()) {
			userName = resultSet.getString(1);
		}
		return userName;
	}

	public int postTweet(TweetPojo tweetData) throws SQLException {
		// TODO Auto-generated method stub

		String postTweetQuery = "INSERT INTO `tweet_app`.`tweet_table`\r\n" + "(\r\n" + "`email_id`,\r\n"
				+ "`tweet_msg`,\r\n" + "`time`)\r\n" + "VALUES\r\n" + "(\r\n" + "?,\r\n" + "?,\r\n" + "?);";

		PreparedStatement statement = connnection.prepareStatement(postTweetQuery);
		statement.setString(1, tweetData.getEmailId());
		statement.setString(2, tweetData.getTweetText());
		statement.setString(3, tweetData.getTime());
		int row = statement.executeUpdate();

		return row;
	}

	public void viewAllTweets(String email) {
		// TODO Auto-generated method stub

	}

	public void viewAllUsers(String email) {
		// TODO Auto-generated method stub

	}

	public void resetMyPassword(String email) {
		// TODO Auto-generated method stub

	}

	public List<ArrayList<String>> showMyTweet(String email) throws SQLException {
		// TODO Auto-generated method stub
		String getMyTweetQuery = "SELECT tweet_msg,time FROM tweet_table where email_id=?";
		PreparedStatement statement = connnection.prepareStatement(getMyTweetQuery);
		statement.setString(1, email);
		ResultSet resultSet = statement.executeQuery();
		List<ArrayList<String>> storeData = new ArrayList<ArrayList<String>>();

		while (resultSet.next()) {
			ArrayList<String> tweetData = new ArrayList<String>();
			tweetData.add(resultSet.getString(1));
			tweetData.add(resultSet.getString(2));
			storeData.add(tweetData);
		}

		return storeData;

	}

	public List<TweetPojo> showAllTweets() throws SQLException {
		// TODO Auto-generated method stub
		String getAllQuery = "SELECT * FROM tweet_table";
		PreparedStatement statement = connnection.prepareStatement(getAllQuery);
		ResultSet resultSet = statement.executeQuery();
		List<TweetPojo> tweetData = new ArrayList<TweetPojo>();

		while (resultSet.next()) {
			TweetPojo pojoData = new TweetPojo();
			pojoData.setEmailId(resultSet.getString("email_id"));
			pojoData.setTweetText(resultSet.getString("tweet_msg"));
			pojoData.setTime(resultSet.getString("time"));
			tweetData.add(pojoData);
		}
		return tweetData;
	}

	public List<ArrayList<String>> showAllUsers() throws SQLException {
		// TODO Auto-generated method stub
		String getAllUsers = "SELECT first_name,email_id FROM user_table ";
		PreparedStatement statement = connnection.prepareStatement(getAllUsers);
		ResultSet resultSet = statement.executeQuery();
		List<ArrayList<String>> storeData = new ArrayList<ArrayList<String>>();

		while (resultSet.next()) {
			ArrayList<String> userData = new ArrayList<String>();
			userData.add(resultSet.getString(1));
			userData.add(resultSet.getString(2));
			storeData.add(userData);
		}
		return storeData;
	}

}
