package com.tweetapp.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	static Connection connection = null;

	static {
		try {
			Properties properties = new Properties();
			FileInputStream input = new FileInputStream(
					"C:\\Users\\User\\Documents\\TwitterApp Console based appication\\TweetApp\\src\\main\\resources\\db.properties");
			properties.load(input);
			input.close();

			String url = properties.getProperty("jdbc.url");
			String userName = properties.getProperty("jdbc.username");
			String password = properties.getProperty("jdbc.password");
			String driverName = properties.getProperty("jdbc.driver");

			Class.forName(driverName);
			connection = DriverManager.getConnection(url, userName, password);

		} catch (FileNotFoundException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		return connection;

	}

}
