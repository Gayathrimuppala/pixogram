package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tweetapp.pojo.RegisterUser;

public class HomeDao {

	static Connection connnection = DBConnection.getConnection();

	public boolean addUser(RegisterUser user) throws SQLException {

		boolean validUser = false;
		String checkUserQuery = "SELECT Count(*) FROM tweet_app.user_table Where email_id=? ";
		PreparedStatement statementCheck = connnection.prepareStatement(checkUserQuery);
		statementCheck.setString(1, user.getEmail());
		ResultSet resultSet = statementCheck.executeQuery();
		int count = -1;
		while (resultSet.next()) {
			count = Integer.parseInt(resultSet.getString(1));

		}
		if (count == 0) {

			String insertQuery = "INSERT INTO `tweet_app`.`user_table`\r\n" + "(`email_id`,\r\n" + "`first_name`,\r\n"
					+ "`last_name`,\r\n" + "`gender`,\r\n" + "`dob`,\r\n" + "`password`,\r\n" + "`status`)\r\n"
					+ "VALUES\r\n" + "(?,\r\n" + "?,\r\n" + "?,\r\n" + "?,\r\n" + "?,\r\n" + "?,\r\n" + "?);";
			PreparedStatement statement = connnection.prepareStatement(insertQuery);
			statement.setString(1, user.getEmail());
			statement.setString(2, user.getFirstName());
			statement.setString(3, user.getLastName());
			statement.setString(4, user.getGender());
			statement.setString(5, user.getDob());
			statement.setString(6, user.getPassword());
			statement.setString(7, "Inactive");
			statement.executeUpdate();
			validUser = true;

		} else {
			validUser = false;
		}
		return validUser;

	}

	public String checkLogin(String email) throws SQLException {
		// TODO Auto-generated method stub

		String credentialsQuery = "SELECT password FROM tweet_app.user_table Where email_id=?; ";
		PreparedStatement statement = connnection.prepareStatement(credentialsQuery);
		statement.setString(1, email);
		ResultSet resultSet = statement.executeQuery();
		String dbPassword = null;
		while (resultSet.next()) {
			dbPassword = resultSet.getString(1);
		}

		return dbPassword;
	}

	public int CheckUser(String email, String dob) throws SQLException {
		// TODO Auto-generated method stub

		String checkUserQuery = "SELECT Count(*) FROM tweet_app.user_table Where email_id=? and dob=?; ";
		PreparedStatement statement = connnection.prepareStatement(checkUserQuery);
		statement.setString(1, email);
		statement.setString(2, dob);
		ResultSet resultSet = statement.executeQuery();
		int count = 0;
		while (resultSet.next()) {
			count = Integer.parseInt(resultSet.getString(1));

		}

		return count;
	}

	public int resetPassword(String newPassword, String email) throws SQLException {
		// TODO Auto-generated method stub

		String updatePasswordQuery = "UPDATE user_table " + "SET   password = ? WHERE email_id = ?;";
		PreparedStatement statement = connnection.prepareStatement(updatePasswordQuery);
		statement.setString(1, newPassword);
		statement.setString(2, email);
		int result = statement.executeUpdate();

		return result;
	}

	public void changeStatus(String email, String status) throws SQLException {
		// TODO Auto-generated method stub
		String updatePasswordQuery = "UPDATE user_table " + "SET   status = ? WHERE email_id = ?;";
		PreparedStatement statement = connnection.prepareStatement(updatePasswordQuery);
		statement.setString(1, status);
		statement.setString(2, email);
		statement.executeUpdate();
	}
}
