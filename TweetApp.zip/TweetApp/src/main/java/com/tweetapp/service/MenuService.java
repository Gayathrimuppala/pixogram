package com.tweetapp.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.sql.SQLException;

public class MenuService {
	HomeService homeService = new HomeService();

	public static void Welcome() {
		System.out.println("*********Welome to TweetApp**********\n");
	}

	public void homeMenu() throws IOException, SQLException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		char option;
		System.out.println("----Home Menu----\nPlease choose your option below\n");
		System.out.println("1-Register\n2-Login\n3-Forget/Change Password\npress other keys to exit the application");
		System.out.println("Enter your option");
		option = (char) input.read();
		switch (option) {
		case '1':
			homeService.registerUser();

			break;
		case '2':
			homeService.login();
			break;
		case '3':
			homeService.resetPassword();

			homeMenu();
			break;

		default:

			break;
		}
	}

	public void userMenu(String userName, String email) throws IOException, SQLException {
		UserService userService = new UserService();
		System.out.println("Hi " + userName + " !");
		System.out.println("Your Tweet App Id <" + email + ">");
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		char option;
		System.out.println("----User Menu----\nPlease choose your option below\n");
		System.out.println(
				"1-Post a tweet\n2-View my Tweets\n3-View all Tweets\n4-View All Users\n5- Reset Password\npress other keys to logout");
		System.out.println("Enter your option");
		option = (char) input.read();
		switch (option) {
		case '1':
			userService.postTweet(userName, email);
			break;
		case '2':
			userService.viewMyTweets(userName, email);
			break;
		case '3':
			userService.viewAllTweets(userName, email);
			break;
		case '4':
			userService.viewAllUsers(userName, email);
			break;
		case '5':
			userService.resetMyPassword(userName, email);
			break;

		default:
			userService.logOff(email);

			homeMenu();
			break;
		}

	}

	public void check() {

	}

}
