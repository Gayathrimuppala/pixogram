package com.tweetapp.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.tweetapp.dao.HomeDao;
import com.tweetapp.dao.UserDao;
import com.tweetapp.pojo.RegisterUser;

public class HomeService {

	public void registerUser() throws IOException, SQLException {
		MenuService menu = new MenuService();
		HomeDao homeDao = new HomeDao();
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		RegisterUser user = new RegisterUser();
		System.out.println("\nEnter your First Name (Required):");
		user.setFirstName(bf.readLine());
		System.out.println("\nEnter your Last Name :");
		user.setLastName(bf.readLine());
		System.out.println("\nEnter your Gender (Required):");
		user.setGender(bf.readLine());
		System.out.println("\nEnter your DOB in dd-MM-yyyy format :");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String dob = bf.readLine();
		Date date = null;
		try {
			date = dateFormat.parse(dob);
			String strDate = dateFormat.format(date);
			user.setDob(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid Date format please Register again");
			System.gc();
			menu.homeMenu();
			System.out.println("Thanks for Using TweetApp");
			System.exit(0);
		}

		System.out.println("\nEnter your Email (Required):");
		user.setEmail(bf.readLine());
		System.out.println("\nEnter your Password (Required) :");
		user.setPassword(bf.readLine());

		if (!user.getEmail().isEmpty() && !user.getFirstName().isEmpty() && !user.getGender().isEmpty()
				&& !user.getPassword().isEmpty()) {
			boolean result = homeDao.addUser(user);
			if (result) {
				System.out.println("**********Registered successfully**********");
			} else {
				System.out.println("Invalid User ,Please try again  with new email Id");
			}
		} else {
			System.out.println("Sorry you failed to enter required fields ,Please Register Again !!!");
		}
		menu.homeMenu();
	}

	public void login() throws IOException, SQLException {
		String email, password;
		HomeDao homeDao = new HomeDao();
		UserDao userDao = new UserDao();
		MenuService menu = new MenuService();
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("***Please Enter your Credentials******");
		System.out.println("\nEnter your registered Email Id:");
		email = bf.readLine();
		System.out.println("\nEnter your Password:");
		password = bf.readLine();
		String dbPassword = homeDao.checkLogin(email);

		if (password.equals(dbPassword) && !password.isEmpty()) {
			System.out.println("****Login Successful*****");
			String status = "Active";
			homeDao.changeStatus(email, status);
			String userName = userDao.getUserName(email);
			if (!userName.isEmpty()) {
				menu.userMenu(userName, email);
			} else {
				System.out.println("There is some technal issues.\nPlease log at some time");
			}
		}

		else {
			System.out.println("Invalid credentials please try again!"
					+ "\n If you forget the password then please update new password\n");
			menu.homeMenu();
		}

	}

	public void resetPassword() throws IOException, SQLException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		String email, dob, newPassword, confirmPassword;

		System.out.println("Please Enter you Registered email ID");
		email = bf.readLine();
		System.out.println("Please Enter your Date of Birth in dd-MM-yyyy format [For Security purpose]");
		dob = bf.readLine();
		HomeDao homeDao = new HomeDao();
		int userAvailable = homeDao.CheckUser(email, dob);
		if (userAvailable == 1) {
			System.out.println("Please Enter your New Password");
			newPassword = bf.readLine();
			if (!newPassword.equals(null)) {
				System.out.println("Please Retype your password to confirm");
				confirmPassword = bf.readLine();
				if (newPassword.equals(confirmPassword)) {
					int resetSuccess = homeDao.resetPassword(newPassword, email);
					if (resetSuccess == 1) {
						System.out.println("Your password has been changed !!!\nplease login again with updated one");
					} else {
						System.out.println(
								"Sorry for Inconvinence ,\nThere may be technical error in our side. Your password not yet changed");
					}
				} else {
					System.out.println("Your entered wrong password please try again");

				}
			} else {
				System.out.println("Your are not allowed to set password empty");
			}
		} else {
			System.out.println("You may entered email Id /DOB Wrong!!\nPlease enter correctly to change password");
		}

		MenuService menu = new MenuService();
		menu.homeMenu();

	}

}
