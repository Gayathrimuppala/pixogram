package com.tweetapp.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;
import com.tweetapp.dao.HomeDao;
import com.tweetapp.dao.UserDao;
import com.tweetapp.pojo.TweetPojo;

public class UserService {

	public void postTweet(String userName, String email) throws IOException, SQLException {
		// TODO Auto-generated method stub
		UserDao userDao = new UserDao();
		TweetPojo tweetData = new TweetPojo();
		MenuService userMenu = new MenuService();
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		tweetData.setEmailId(email);
		System.out.println("Please Post your Tweet :");
		tweetData.setTweetText(bf.readLine());
		Date date = java.util.Calendar.getInstance().getTime();
		String time = date.toString();
		tweetData.setTime(time);

		int result = userDao.postTweet(tweetData);
		if (result == 1) {
			System.out.println("Tweet Posted Succssfully\n");
			userMenu.userMenu(userName, email);

		} else {
			System.out.println("Due to some technical error tweet was not posted");
			userMenu.userMenu(userName, email);
		}

	}

	public void viewMyTweets(String userName, String email) throws SQLException, IOException {
		// TODO Auto-generated method stub
		UserDao userDao = new UserDao();
		MenuService userMenu = new MenuService();
		List<ArrayList<String>> storeTweetData = new ArrayList<ArrayList<String>>();
		System.out.println("****************************************" + "\nYour Tweets:");
		storeTweetData = userDao.showMyTweet(email);
		if (storeTweetData == null) {
			System.out.println("You don't have any tweets");
			System.out.println("/n****************************************");
			userMenu.userMenu(userName, email);
		} else {
			Stream<ArrayList<String>> obj = storeTweetData.stream();
			obj.forEach(data -> System.out.println("Tweet:" + data.get(0) + "\n[Time]@" + data.get(1) + "\n"));
			System.out.println("/n****************************************");
			userMenu.userMenu(userName, email);

		}

	}

	public void viewAllTweets(String userName, String email) throws SQLException, IOException {
		// TODO Auto-generated method stub
		UserDao userDao = new UserDao();
		MenuService userMenu = new MenuService();
		List<TweetPojo> storeTweetData = new ArrayList<>();
		System.out.println("\n******************************"
				+ "\nAll Tweets:\n");
		storeTweetData = userDao.showAllTweets();
		if (storeTweetData == null) {
			System.out.println("There is no tweet available");
			userMenu.userMenu(userName, email);
		} else {
			Stream<TweetPojo> obj = storeTweetData.stream();
			obj.forEach(data -> System.out.println("Tweet: " + data.getTweetText() + "\n[User<" + data.getEmailId()
					+ "> @ " + data.getTime() + "]\n"));
			System.out.println("\n**************************************");

			userMenu.userMenu(userName, email);
		}

	}

	public void viewAllUsers(String userName, String email) throws SQLException, IOException {
		// TODO Auto-generated method stub
		UserDao userDao = new UserDao();
		MenuService userMenu = new MenuService();
		List<ArrayList<String>> storeUserData = new ArrayList<ArrayList<String>>();
		storeUserData = userDao.showAllUsers();
		System.out.println("*********User's List**********\n");
		if (storeUserData == null) {
			System.out.println("User Data Unavailable");
			userMenu.userMenu(userName, email);
		} else {
			Stream<ArrayList<String>> obj = storeUserData.stream();
			obj.forEach(data -> System.out.println(data.get(0) + " <" + data.get(1) + ">"));
			System.out.println("\n******************\n");

			userMenu.userMenu(userName, email);
		}
	}

	public void resetMyPassword(String userName, String email) throws IOException, SQLException {
		// TODO Auto-generated method stub
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		HomeDao homeDao = new HomeDao();
		MenuService menu = new MenuService();
		String newPassword;
		String confirmPassword;
		System.out.println("Please Enter your New Password");
		newPassword = bf.readLine();
		System.out.println("Please Retype your password to confirm");
		confirmPassword = bf.readLine();
		if (newPassword.equals(confirmPassword)) {
			int resetSuccess = homeDao.resetPassword(newPassword, email);
			if (resetSuccess == 1) {
				System.out.println("Your password has been changed !!!\nplease login again with updated one");
				String status = "Inactive";
				homeDao.changeStatus(email, status);
				menu.homeMenu();
			} else {
				System.out.println(
						"Sorry for Inconvinence ,\nThere may be technical error in our side. Your password not yet changed");
				menu.userMenu(userName, email);
			}
		} else {
			System.out.println("Your entered wrong password please try again");
			menu.userMenu(userName, email);

		}

	}

	public void logOff(String email) throws SQLException {
		// TODO Auto-generated method stub
		HomeDao homeDao = new HomeDao();
		String status = "Inactive";
		homeDao.changeStatus(email, status);
		System.out.println("You successfully logged off");

	}

}
