import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchComponent } from './search.component';
import { AppComponent } from '../app.component';
import { HeaderComponent } from '../com/header/header.component';
import { SignInComponent } from '../sign-in/sign-in.component';
import { RegisterComponent } from '../register/register.component';
import { MyMediaPageComponent } from '../my-media-page/my-media-page.component';
import { UploadMediaSingleComponent } from '../upload-media/upload-media-single/upload-media-single.component';
import { UploadMediaMultipleComponent } from '../upload-media/upload-media-multiple/upload-media-multiple.component';
import { UserCardComponent } from '../com/user-card/user-card.component';
import { MediaCardComponent } from '../com/media-card/media-card.component';
import { MediaHolderCardComponent } from '../com/media-holder-card/media-holder-card.component';
import { MediaDetailComponent } from '../media-detail/media-detail.component';
import { AccountDetailsComponent } from '../account-details/account-details.component';
import { AccountUpdateComponent } from '../account-update/account-update.component';
import { BlockedAccountsComponent } from '../blocked-accounts/blocked-accounts.component';
import { NewsFeedComponent } from '../news-feed/news-feed.component';
import { UploadMediaComponent } from '../upload-media/upload-media.component';
import { FollowComponent } from '../follow/follow.component';
import { FollowersComponent } from '../followers/followers.component';
import { FollowingComponent } from '../following/following.component';
import { FollowingsMediaComponent } from '../followings-media/followings-media.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

describe('SearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        HeaderComponent,
        SignInComponent,
        RegisterComponent,
        MyMediaPageComponent,
        UploadMediaSingleComponent,
        UploadMediaMultipleComponent,
        UserCardComponent,
        MediaCardComponent,
        MediaHolderCardComponent,
        MediaDetailComponent,
        AccountDetailsComponent,
        AccountUpdateComponent,
        BlockedAccountsComponent,
        NewsFeedComponent,
        SearchComponent,
        UploadMediaComponent,
        FollowComponent,
        FollowersComponent,
        FollowingComponent,
        FollowingsMediaComponent
      ],
      imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
