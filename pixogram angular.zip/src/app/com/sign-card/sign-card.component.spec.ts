import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignCardComponent } from './sign-card.component';
import { AppComponent } from 'src/app/app.component';
import { HeaderComponent } from '../header/header.component';
import { SignInComponent } from 'src/app/sign-in/sign-in.component';
import { RegisterComponent } from 'src/app/register/register.component';
import { MyMediaPageComponent } from 'src/app/my-media-page/my-media-page.component';
import { UploadMediaSingleComponent } from 'src/app/upload-media/upload-media-single/upload-media-single.component';
import { UploadMediaMultipleComponent } from 'src/app/upload-media/upload-media-multiple/upload-media-multiple.component';
import { UserCardComponent } from '../user-card/user-card.component';
import { MediaCardComponent } from '../media-card/media-card.component';
import { MediaHolderCardComponent } from '../media-holder-card/media-holder-card.component';
import { MediaDetailComponent } from 'src/app/media-detail/media-detail.component';
import { AccountDetailsComponent } from 'src/app/account-details/account-details.component';
import { AccountUpdateComponent } from 'src/app/account-update/account-update.component';
import { BlockedAccountsComponent } from 'src/app/blocked-accounts/blocked-accounts.component';
import { NewsFeedComponent } from 'src/app/news-feed/news-feed.component';
import { SearchComponent } from 'src/app/search/search.component';
import { UploadMediaComponent } from 'src/app/upload-media/upload-media.component';
import { FollowComponent } from 'src/app/follow/follow.component';
import { FollowersComponent } from 'src/app/followers/followers.component';
import { FollowingComponent } from 'src/app/following/following.component';
import { FollowingsMediaComponent } from 'src/app/followings-media/followings-media.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

describe('SignCardComponent', () => {
  let component: SignCardComponent;
  let fixture: ComponentFixture<SignCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        HeaderComponent,
        SignInComponent,
        RegisterComponent,
        MyMediaPageComponent,
        UploadMediaSingleComponent,
        UploadMediaMultipleComponent,
        UserCardComponent,
        MediaCardComponent,
        MediaHolderCardComponent,
        MediaDetailComponent,
        AccountDetailsComponent,
        AccountUpdateComponent,
        BlockedAccountsComponent,
        NewsFeedComponent,
        SearchComponent,
        UploadMediaComponent,
        FollowComponent,
        FollowersComponent,
        FollowingComponent,
        FollowingsMediaComponent
      ],
      imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
