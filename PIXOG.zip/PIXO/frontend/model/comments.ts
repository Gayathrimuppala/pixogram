export class comments{

constructor(public userId:number,public postId:number,public comment:String){}

}