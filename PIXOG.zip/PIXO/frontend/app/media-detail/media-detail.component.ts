import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';
import { Media } from 'src/model/media';
import { Title }     from '@angular/platform-browser';
import { MediaService } from 'src/services/media.service';

@Component({
  selector: 'app-media-detail',
  templateUrl: './media-detail.component.html',
  styleUrls: ['./media-detail.component.css']
})
export class MediaDetailComponent implements OnInit {

  mediaDetails: Media;
  description: String;
  tags: String;
  id:number;
  comments:Comment;
  constructor(private dataService: DataService, private titleService: Title,public mediaService:MediaService) {
    titleService.setTitle('Media Details');
   }

  ngOnInit() {
    this.dataService.mediaDetails$.subscribe(m => this.mediaDetails = m);
    this.description = this.mediaDetails.description;
    this.tags = this.mediaDetails.tags;
    this.id=this.mediaDetails.id;
    //this.mediaService.getComments(this.mediaDetails.userId,this.mediaDetails.id).subscribe((response)=>{
      //this.comments=response;
      //console.log(this.comments);
    // });
  }

  onSubmit() {

  }
}
