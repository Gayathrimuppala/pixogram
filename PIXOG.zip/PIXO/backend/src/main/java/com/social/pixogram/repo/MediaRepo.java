package com.social.pixogram.repo;

import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.Media;

public interface MediaRepo extends CrudRepository<Media, Long> {

}
